object Form1: TForm1
  Left = 156
  Top = 81
  Width = 732
  Height = 634
  Caption = 'Form1'
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  Menu = Main_menu
  OldCreateOrder = False
  PixelsPerInch = 96
  TextHeight = 13
  object lbl_enter: TLabel
    Left = 8
    Top = 16
    Width = 264
    Height = 13
    Caption = #1042#1074#1077#1076#1080#1090#1077' '#1090#1077#1089#1082#1089#1090' '#1080#1083#1080' '#1086#1090#1082#1088#1086#1081#1090#1077' '#1092#1072#1081#1083' '#1076#1083#1103' '#1086#1073#1088#1072#1073#1086#1090#1082#1080':'
  end
  object lbl_error: TLabel
    Left = 304
    Top = 16
    Width = 56
    Height = 17
    Caption = #13#10
  end
  object lbl_even: TLabel
    Left = 16
    Top = 336
    Width = 62
    Height = 13
    Caption = #1042#1089#1077' '#1095#1077#1090#1085#1099#1077':'
  end
  object lbl_not_even: TLabel
    Left = 368
    Top = 336
    Width = 77
    Height = 13
    Caption = #1042#1089#1077' '#1085#1077' '#1095#1077#1090#1085#1099#1077':'
  end
  object Memo_enter: TMemo
    Left = 0
    Top = 32
    Width = 713
    Height = 289
    ScrollBars = ssBoth
    TabOrder = 0
    OnKeyPress = Memo_enterKeyPress
  end
  object Memo_output_even: TMemo
    Left = 0
    Top = 352
    Width = 353
    Height = 217
    ScrollBars = ssBoth
    TabOrder = 1
  end
  object Memo_output_not_even: TMemo
    Left = 360
    Top = 352
    Width = 353
    Height = 217
    TabOrder = 2
  end
  object Main_menu: TMainMenu
    Left = 392
    object N1: TMenuItem
      Caption = #1060#1072#1081#1083
      object Save: TMenuItem
        Caption = #1057#1086#1093#1088#1072#1085#1080#1090#1100
        OnClick = SaveClick
      end
      object Save_as: TMenuItem
        Caption = #1057#1086#1093#1088#1072#1085#1080#1090#1100' '#1082#1072#1082
        OnClick = Save_asClick
      end
      object Open: TMenuItem
        Caption = #1054#1090#1082#1088#1099#1090#1100
        OnClick = OpenClick
      end
      object Clear: TMenuItem
        Caption = #1054#1095#1080#1089#1090#1080#1090#1100
        OnClick = ClearClick
      end
      object New: TMenuItem
        Caption = #1053#1086#1074#1099#1081
        OnClick = NewClick
      end
      object Exit: TMenuItem
        Caption = #1042#1099#1081#1090#1080
        OnClick = ExitClick
      end
    end
    object Run: TMenuItem
      Caption = 'Run'
      OnClick = RunClick
    end
  end
  object Open_Dialog: TOpenDialog
    Left = 456
  end
  object Save_Dialog: TSaveDialog
    Left = 520
  end
end
